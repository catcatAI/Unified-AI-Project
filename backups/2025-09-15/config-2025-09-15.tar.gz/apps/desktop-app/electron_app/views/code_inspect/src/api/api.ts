import axios, { AxiosRequestConfig, AxiosError, InternalAxiosRequestConfig, AxiosInstance } from 'axios';
import JSONbig from 'json-bigint';



const localApi = axios.create({
  headers: {
    'Content-Type': 'application/json',
  },
  validateStatus: (status) => {
    return status >= 200 && status < 300;
  },
  transformResponse: [(data) => JSONbig.parse(data)]
});



let accessToken: string | null = null;

const getApiInstance = (url: string) => {
  return async (config) => {
    const channel = `api:${config.method || 'get'}:${url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, config.data || config.params);
  };
};

const isAuthEndpoint = (url: string): boolean => {
  return url.includes("/api/auth");
};

// Check if the URL is for the refresh token endpoint to avoid infinite loops
const isRefreshTokenEndpoint = (url: string): boolean => {
  return url.includes("/api/auth/refresh");
};

const setupInterceptors = (apiInstance: typeof axios) => {
  apiInstance.interceptors.request.use(
    (config: InternalAxiosRequestConfig): InternalAxiosRequestConfig => {

      if (!accessToken) {
        accessToken = localStorage.getItem('accessToken');
      }
      if (accessToken && config.headers) {
        config.headers.Authorization = `Bearer ${accessToken}`;
      }

      return config;
    },
    (error: AxiosError): Promise<AxiosError> => Promise.reject(error)
  );

  apiInstance.interceptors.response.use(
    (response) => response,
    async (error: AxiosError): Promise<any> => {
      const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

      // Only refresh token when we get a 401/403 error (token is invalid/expired)
      if (error.response?.status && [401, 403].includes(error.response.status) &&
          !originalRequest._retry &&
          originalRequest.url && !isRefreshTokenEndpoint(originalRequest.url)) {
        originalRequest._retry = true;

        try {
          const refreshToken = localStorage.getItem('refreshToken');
          if (!refreshToken) {
            throw new Error('No refresh token available');
          }

          const response = await localApi.post(`/api/auth/refresh`, {
            refreshToken,
          });

          if (response.data.data) {
            const newAccessToken = response.data.data.accessToken;
            const newRefreshToken = response.data.data.refreshToken;

            localStorage.setItem('accessToken', newAccessToken);
            localStorage.setItem('refreshToken', newRefreshToken);
            accessToken = newAccessToken;

            if (originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
            }
          } else {
            throw new Error('Invalid response from refresh token endpoint');
          }

          if (originalRequest.headers) {
            originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          }
          return getApiInstance(originalRequest.url || '')(originalRequest);
        } catch (err) {
          localStorage.removeItem('refreshToken');
          localStorage.removeItem('accessToken');
          accessToken = null;
          window.location.href = '/login';
          return Promise.reject(err);
        }
      }

      return Promise.reject(error);
    }
  );
};

setupInterceptors(localApi);



const api = {
  request: async (config: AxiosRequestConfig) => {
    const channel = `api:${config.method || 'get'}:${config.url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, config.data || config.params);
  },
  get: async (url: string, config?: AxiosRequestConfig) => {
    const channel = `api:get:${url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, config?.params);
  },
  post: async (url: string, data?: any, config?: AxiosRequestConfig) => {
    const channel = `api:post:${url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, data);
  },
  put: async (url: string, data?: any, config?: AxiosRequestConfig) => {
    const channel = `api:put:${url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, data);
  },
  delete: async (url: string, config?: AxiosRequestConfig) => {
    const channel = `api:delete:${url}`.toLowerCase();
    return await window.electronAPI.invoke(channel, config?.params);
  },
};

export default api;
