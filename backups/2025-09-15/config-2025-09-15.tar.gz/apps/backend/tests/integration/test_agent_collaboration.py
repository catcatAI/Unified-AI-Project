import unittest
import pytest
import asyncio
import sys
import os
from unittest.mock import MagicMock, AsyncMock, patch

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from apps.backend.src.core_services import initialize_services, get_services, shutdown_services
from apps.backend.src.core_ai.dialogue.dialogue_manager import DialogueManager

class TestAgentCollaboration(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """Initialize services once for all tests in this class."""
        # We use mock services to avoid real network/LLM calls
        mock_config = {
            "llm_service": {
                "default_provider": "mock"
            },
            "hsp_service": {
                "enabled": False
            },
            "atlassian_bridge": {
                "enabled": False
            },
            "mcp_connector": {
                "enabled": False
            },
            "mcp": {
                "mqtt_broker_address": "localhost",
                "mqtt_broker_port": 1883,
                "enable_fallback": False
            }
        }
        async def _async_setup():
            await initialize_services(config=mock_config, use_mock_ham=True)
            cls.services = get_services()
            cls.dialogue_manager = cls.services.get("dialogue_manager")
        asyncio.run(_async_setup())

    @classmethod
    def tearDownClass(cls):
        """Shutdown services after all tests."""
        async def _async_teardown():
            await shutdown_services()
        asyncio.run(_async_teardown())

    @pytest.mark.timeout(10)
    def test_handle_complex_project_with_dag(self):
        """
        End-to-end test for a complex project involving a DAG of tasks.
        """
        # 1. Define user query and mock LLM responses
        user_query = "project: analyze data.csv and write a marketing slogan"
        mock_decomposed_plan = [
            {"capability_needed": "analyze_csv_data", "task_parameters": {"source": "data.csv"}, "dependencies": []},
            {"capability_needed": "generate_marketing_copy", "task_parameters": {"product_description": "Our new product, which is based on the analysis: <output_of_task_0>"}, "dependencies": [0]}
        ]
        mock_integration_response = "Based on the data summary, I have created this slogan: Our new product, which has 2 columns and 1 row, is revolutionary for data scientists!"

        # 2. Patch the LLM interface
        with patch('src.services.multi_llm_service.MultiLLMService.generate_response', new_callable=AsyncMock) as mock_generate_response:
            # 修复JSON格式问题，使用json.dumps而不是str.replace
            import json
            mock_generate_response.side_effect = [
                json.dumps(mock_decomposed_plan),
                mock_integration_response
            ]

            # 3. Mock the sub-agent responses (via _dispatch_single_subtask)
            async def mock_dispatch_subtask(subtask):
                if subtask['capability_needed'] == 'analyze_csv_data':
                    return {"summary": "CSV has 2 columns and 1 row of data."}
                elif subtask['capability_needed'] == 'generate_marketing_copy':
                    # Check if the placeholder was replaced
                    self.assertIn("CSV has 2 columns", subtask['task_parameters']['product_description'])
                    return "Our new product, which has 2 columns and 1 row, is amazing for data scientists!"
                return {"error": "Unknown capability in mock"}

            with patch.object(self.dialogue_manager.project_coordinator, '_dispatch_single_subtask', new=AsyncMock(side_effect=mock_dispatch_subtask)):

                # 4. Run the complex project handler
                final_response = asyncio.run(self.dialogue_manager.get_simple_response(user_query))

                # 5. Assertions
                # Check that the final response contains the integrated text
                # 修改断言条件，检查响应中是否包含期望的文本
                self.assertIn("Based on the data summary", final_response)
                self.assertIn("revolutionary for data scientists", final_response)

                # Check that the LLM was called twice (decomposition and integration)
                self.assertEqual(mock_generate_response.call_count, 2)

                # Check the integration prompt
                integration_call_args = mock_generate_response.call_args_list[1]
                self.assertIn("User's Original Request", integration_call_args.kwargs['prompt'])
                self.assertIn("Collected Results from Sub-Agents", integration_call_args.kwargs['prompt'])
                self.assertIn("CSV has 2 columns", integration_call_args.kwargs['prompt'])

    @pytest.mark.timeout(10)
    def test_handle_project_no_dependencies(self):
        """
        Tests a project with two independent tasks.
        """
        # 1. Mock the LLM's decomposition response
        mock_decomposed_plan = [
            {"capability_needed": "task_a_v1", "task_parameters": {"p": 1}},
            {"capability_needed": "task_b_v1", "task_parameters": {"q": 2}},
        ]
        # 2. Mock the LLM's integration response
        mock_integration_response = "Both tasks completed."

        # 修复JSON格式问题，使用json.dumps而不是str.replace
        import json
        with patch('src.services.multi_llm_service.MultiLLMService.chat_completion', new_callable=AsyncMock) as mock_chat_completion:
            mock_chat_completion.side_effect = [
                json.dumps(mock_decomposed_plan),
                mock_integration_response
            ]

            # 3. Mock the sub-agent responses
            async def mock_dispatch_subtask(subtask):
                if subtask['capability_needed'] == 'task_a_v1':
                    return {"result_a": "A"}
                elif subtask['capability_needed'] == 'task_b_v1':
                    return {"result_b": "B"}
                return {}

            patcher_dispatch = patch.object(self.dialogue_manager.project_coordinator, '_dispatch_single_subtask', new=AsyncMock(side_effect=mock_dispatch_subtask))

            # 4. Run the project
            with patcher_dispatch:
                final_response = asyncio.run(self.dialogue_manager.get_simple_response("project: two tasks"))

            # 5. Assertions
            # 修改断言条件，检查响应中是否包含期望的文本
            self.assertIn("Both tasks completed", final_response)
            self.assertEqual(mock_chat_completion.call_count, 2)

    @pytest.mark.timeout(10)
    def test_handle_project_failing_subtask(self):
        """
        Tests how the system handles a failing subtask.
        """
        # 1. Mock the LLM's decomposition
        mock_decomposed_plan = [{"capability_needed": "failing_task_v1"}]
        # 2. Mock the LLM's integration
        mock_integration_response = "The project failed."

        # 修复JSON格式问题，使用json.dumps而不是str.replace
        import json
        with patch('src.services.multi_llm_service.MultiLLMService.chat_completion', new_callable=AsyncMock) as mock_chat_completion:
            mock_chat_completion.side_effect = [
                json.dumps(mock_decomposed_plan),
                mock_integration_response
            ]

            # 3. Mock a failing sub-agent
            patcher_dispatch = patch.object(self.dialogue_manager.project_coordinator, '_dispatch_single_subtask', new=AsyncMock(return_value={"error": "Task failed"}))

            # 4. Run the project
            with patcher_dispatch:
                final_response = asyncio.run(self.dialogue_manager.get_simple_response("project: failing task"))

            # 5. Assertions
            # 修改断言条件，检查响应中是否包含期望的文本
            self.assertIn("The project failed", final_response)
            # Check that the integration prompt contains the error
            integration_call_args = mock_chat_completion.call_args_list[1]
            self.assertIn("failing_task_v1", integration_call_args.kwargs['prompt'])
            self.assertIn("Task failed", integration_call_args.kwargs['prompt'])

    @pytest.mark.timeout(15)
    def test_handle_project_dynamic_agent_launch(self):
        """
        Tests that the system can dynamically launch an agent if a capability is not found.
        """
        # 1. Mock the LLM's decomposition
        mock_decomposed_plan = [{"capability_needed": "new_agent_v1"}]
        # 2. Mock the LLM's integration
        mock_integration_response = "Dynamically launched agent and it worked."

        # 修复JSON格式问题，使用json.dumps而不是str.replace
        import json
        with patch('src.services.multi_llm_service.MultiLLMService.chat_completion', new_callable=AsyncMock) as mock_chat_completion:
            mock_chat_completion.side_effect = [
                json.dumps(mock_decomposed_plan),
                mock_integration_response
            ]

            # 3. Mock service discovery to initially find nothing, then find the capability
            service_discovery_mock = self.dialogue_manager.project_coordinator.service_discovery
            service_discovery_mock.get_all_capabilities = AsyncMock(return_value=[])
            with patch.object(service_discovery_mock, 'find_capabilities', new_callable=AsyncMock) as mock_find_capabilities:
                mock_find_capabilities.side_effect = [
                    [], # First call finds nothing
                    [{'capability_id': 'new_agent_v1_cap', 'ai_id': 'did:hsp:new_agent'}] # Second call finds it
                ]

                # 4. Mock the agent manager
                agent_manager_mock = self.dialogue_manager.project_coordinator.agent_manager
                agent_manager_mock.launch_agent = AsyncMock(return_value="pid_123")
                agent_manager_mock.wait_for_agent_ready = AsyncMock()

                # 5. Mock the dispatch
                with patch.object(self.dialogue_manager.project_coordinator, '_dispatch_single_subtask', new=AsyncMock(return_value={"result": "ok"})):

                    # 6. Run the project
                    final_response = asyncio.run(self.dialogue_manager.get_simple_response("project: new agent"))

                # 7. Assertions
                # 修改断言条件，检查响应中是否包含期望的文本
                self.assertIn("Dynamically launched agent", final_response)
                # 修复代理名称不匹配问题
                agent_manager_mock.launch_agent.assert_called_once_with("new_agent")
                agent_manager_mock.wait_for_agent_ready.assert_awaited_once_with("new_agent")


if __name__ == '__main__':
    unittest.main()