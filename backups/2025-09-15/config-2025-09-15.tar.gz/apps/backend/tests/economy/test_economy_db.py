import unittest
import os
import sqlite3
from apps.backend.src.economy.economy_db import EconomyDB

class TestEconomyDB(unittest.TestCase):
    def setUp(self):
        self.db_path = "test_economy.db"
        self.db = EconomyDB(db_path=self.db_path)

    def tearDown(self):
        self.db.close()
        if os.path.exists(self.db_path):
            os.remove(self.db_path)

    def test_init_db(self):
        # Test if the table is created
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='balances';")
        self.assertIsNotNone(cursor.fetchone())
        conn.close()

    def test_get_user_balance_new_user(self):
        balance = self.db.get_user_balance("user1")
        self.assertEqual(balance, 0.0)

    def test_update_user_balance_add(self):
        self.assertTrue(self.db.update_user_balance("user1", 100.0))
        balance = self.db.get_user_balance("user1")
        self.assertEqual(balance, 100.0)

    def test_update_user_balance_debit_sufficient_funds(self):
        self.db.update_user_balance("user2", 200.0)
        self.assertTrue(self.db.update_user_balance("user2", -50.0))
        balance = self.db.get_user_balance("user2")
        self.assertEqual(balance, 150.0)

    def test_update_user_balance_debit_insufficient_funds(self):
        self.db.update_user_balance("user3", 50.0)
        self.assertFalse(self.db.update_user_balance("user3", -100.0)) # Should fail due to insufficient funds
        balance = self.db.get_user_balance("user3")
        self.assertEqual(balance, 50.0) # Balance should remain unchanged

    def test_update_user_balance_multiple_updates(self):
        self.db.update_user_balance("user4", 10.0)
        self.db.update_user_balance("user4", 20.0)
        self.db.update_user_balance("user4", -5.0)
        balance = self.db.get_user_balance("user4")
        self.assertEqual(balance, 25.0)

if __name__ == '__main__':
    unittest.main()
